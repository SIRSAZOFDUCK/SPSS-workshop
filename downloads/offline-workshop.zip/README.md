# SSC2 SPSS Workshop: MH900 template version

This is a separate version of the SPSS workshop. The original workshop and MH900 files have not been modified.

## Open or publish

Open index.html in a browser. To publish on GitHub Pages, upload the contents of this folder to the chosen repository, retaining assets/ and downloads/. In Settings > Pages, select Deploy from a branch and the branch root. No build step or server code is required.

The ZIP alongside this folder contains the complete upload package. The download inside the site is an offline copy; extract it before opening index.html.

## Design

Adapted directly from the E1 MH900 HTML: embedded Schibsted Grotesk and Spline Sans Mono, Warwick colours, light/dark themes, dotted masthead, section number line, question cards, and Back/Next navigation. The Warwick Medical School logo is 76 px high on wide screens, compared with 64 px in E1. Section numbers remain visible in the top navigation.

## Content and privacy

The main journey now has 11 sections: introduction, preparation, normality, independent-samples t-test, paired-samples t-test, ANOVA, comparing medians, crosstabs, linear regression, logistic regression and project application. Help is a separate utility page. Source datasets are unchanged. New normality guidance and median summaries accompany the previously verified t-test results. Completion uses this version's own browser session storage. Section 11 contains five project questions without text boxes or note-saving controls.

SPSS calculations were verified in version 31 on Mac. Windows classroom menu clicks, native printing and a deployed GitHub Pages URL remain untested. The template adaptation does not change those limits.

## Tutor guide

The tutor guide is separate from the student package, saved alongside this folder as SPSS-tutor-guide.html. It is not linked from the student page or included in either ZIP. Its old timetable has not been revised for the three added sections.
